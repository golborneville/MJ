
package com.mj.calendarproto;

import android.os.Bundle;
import androidx.fragment.app.FragmentActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import com.mj.calendarproto.cal.OneDayView;

import java.util.Calendar;


public class MainActivity extends FragmentActivity {

    private static final String TAG = MConfig.TAG;
    private static final String NAME = "MainActivity";
    private final String CLASS = NAME + "@" + Integer.toHexString(hashCode());

    private TextView thisMonthTv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        Button addButton = findViewById(R.id.main_add_bt);
//        Button monthButton = findViewById(R.id.main_monthly_bt);
//        Button weekButton = findViewById(R.id.main_weekly_bt);
//        Button dayButton = findViewById(R.id.main_daily_bt);
        //요 위에있는 버튼들을 가지고 추가할 예정이었어요


        thisMonthTv = findViewById(R.id.this_month_tv);
        
        MonthlyFragment mf = (MonthlyFragment) getSupportFragmentManager().findFragmentById(R.id.monthly);
        mf.setOnMonthChangeListener(new MonthlyFragment.MonthlyFragmentListener() {
            
            @Override
            public void onChange(int year, int month) {
                HLog.d(TAG, CLASS, "onChange " + year + "." + month+1);
                thisMonthTv.setText(year + "." + (month + 1));
            }

            @Override
            //여기 부분을 통해 어느 날짜를 선택했는지 알 수 있습니다.
            public void onDayClick(OneDayView dayView) {
                Toast.makeText(MainActivity.this, "Click  " + ((dayView.get(Calendar.MONTH)+1)%12) + "/" + dayView.get(Calendar.DAY_OF_MONTH), Toast.LENGTH_SHORT)
                    .show();
            }
            //날짜 인자를 넘길때 번거롭지만 (dayView.get(Calendar.MONTH)+1)%12 로 시작하면 됩니다.
            //날짜를 클릭했을때 구글 캘린더에 등록된 값이 있으면 일기 작성으로 넘어가고 있으면 창을 띄워서 일기 내용을 보여주고 밑에 수정버튼을 띄워주자
        });

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        return id == R.id.action_settings || super.onOptionsItemSelected(item);
    }
    
}
