package com.mj.calendarproto;

import com.mj.calendarproto.cal.OneDayView;

import androidx.annotation.NonNull;

public interface MonthlyView {
    void onClickDay(@NonNull OneDayView odv);
    void onMonthChanged(int year, int month);
    int getCurrentPosition();
}
